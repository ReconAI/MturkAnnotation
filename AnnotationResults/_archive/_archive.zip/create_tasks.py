import lib
import sys
import time


# constants
use_sandbox = 1


# functions
def change_url_in_question(new_url):
	path = __file__[:__file__.rfind('/') + 1] + 'questions_template.xml'
	path_new = __file__[:__file__.rfind('/') + 1] + 'questions.xml'
	
	file_new = open(path_new, 'w')
	
	with open(path, 'r') as file:
		for line in file:
			if line.find('var URL = ') > 0: line = line[:line.find('var URL = ') + 11] + new_url + '";\n'
			file_new.write(line)
			pass

		pass

	file_new.close()

	return

def create_hit(mturk, hit_file):
	question = open(name = 'questions.xml', mode = 'r').read()
	new_hit = mturk.create_hit(Title = 'Draw lines on the railways in this picture',
							   Description = 'Locate the railway tracks in the image. Then use your mouse to draw two lines over the tracks.',
							   Keywords = 'images, drawing, localizing',
							   Reward = '0.01',
							   MaxAssignments = 1,
							   LifetimeInSeconds = 60 * 60 * 24 * 5,
							   AssignmentDurationInSeconds = 60 * 5,
							   AutoApprovalDelayInSeconds = 60 * 60 * 24,
							   Question = question,
							   )
	
	hit_file.write(new_hit['HIT']['HITId'] + '\n')
	
	return new_hit['HIT']['HITGroupId']


# main
if __name__ == '__main__':
	mturk = lib.start_session(use_sandbox=use_sandbox)
	lib.display_balance(mturk)
	
	hit_file = open(__file__[:__file__.rfind('/') + 1] + 'hits.txt', 'w')
	hit_group_id = '';

	urls = lib.fetch_txt_entries('urls.txt')
	for it, url in enumerate(urls):
		sys.stdout.write('\rProcessing ' + url + ' (' + str(round(100.0 * (it + 1) / len(urls), 1)) + '%). Balance: $' + mturk.get_account_balance()['AvailableBalance'])
		sys.stdout.flush()

		change_url_in_question(url)
		hit_group_id = create_hit(mturk, hit_file)

		if use_sandbox: break


	hit_file.close()
	sys.stdout.write('\n')
	lib.display_balance(mturk)
	sys.stdout.write('\n\nA new HIT has been created. You can preview it here:\n');
	sys.stdout.write('https://workersandbox.mturk.com/mturk/preview?groupId=' + hit_group_id + '\n')
