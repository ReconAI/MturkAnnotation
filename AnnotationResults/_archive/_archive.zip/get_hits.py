import lib
import sys
import time


# constants
use_sandbox = 0
day = 14


# classes
class url_hit:
	def __init__(self, url):
		self.url = url

	def assign_hit_id(self, hit_id):
		self.hit_id = hit_id


# globals
ids = []


# functions
def get_url(question):
	pos = question.find('URL = ')
	
	return question[pos + 7:pos + 54]


def get_hit_ids(hits):
	for hit in hits:
		if hit['CreationTime'].day != day: return 0
		new_url = get_url(hit['Question'])
		for id in ids:
			if id.url == new_url:
				id.assign_hit_id(hit['HITId'])
				break
	
	
	return 1


# main
if __name__ == '__main__':
	mturk = lib.start_session(use_sandbox=use_sandbox)
	for url in lib.fetch_txt_entries('urls.txt'): ids.append(url_hit(url))
	
	response = mturk.list_hits()
	while get_hit_ids(response['HITs']): response = mturk.list_hits(NextToken=response['NextToken'])

	for id in ids: print(id.hit_id)
	print(len(ids))
	

