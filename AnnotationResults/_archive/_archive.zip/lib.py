import boto3

# constants
MTURK_SANDBOX = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com'
AWS_ACCESS_KEY_ID = 'AKIAI6WWLIDJKS7KVW7A'
AWS_SECRET_ACCESS_KEY = '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'
REGION_NAME = 'us-east-1'


# functions
def start_session(use_sandbox):
	if use_sandbox:
		mturk = boto3.client('mturk',
							 aws_access_key_id = AWS_ACCESS_KEY_ID,
							 aws_secret_access_key = AWS_SECRET_ACCESS_KEY,
							 region_name = REGION_NAME,
							 endpoint_url = MTURK_SANDBOX
							 )
		
		return mturk
	
	mturk = boto3.client('mturk',
						 aws_access_key_id = AWS_ACCESS_KEY_ID,
						 aws_secret_access_key = AWS_SECRET_ACCESS_KEY,
						 region_name = REGION_NAME,
						 )

	return mturk

def display_balance(mturk):
	print('Balance: $' + mturk.get_account_balance()['AvailableBalance'])
	
	return

def fetch_txt_entries(file_name):
	path = __file__[:__file__.rfind('/') + 1] + file_name
	
	entries = []
	with open(path, 'r') as file:
		for line in file:
			if line[-1] == '\n': line = line[:-1]
			entries.append(line)
			pass
	
	return entries

def get_frame_numbers(video_name):
	path = __file__[:__file__.rfind('/') + 1] + video_name + '/' + video_name + '.txt'
	frame_numbers = []
	
	with open(path, 'r') as file:
		for line in file:
			line = line[:-1]
			if line.isdigit(): frame_numbers.append(line)
			pass
	
	return frame_numbers
