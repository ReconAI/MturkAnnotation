import lib
import xmltodict
import sys

# vars
vid_id = 'GP030088'


# functions
def get_hit_result(id, it, max_num, frame_number, save_file):
	sys.stdout.write('\rProcessing: ' + id + ' (' + str(round(100.0 * it / max_num, 1)) + '%)')
	sys.stdout.flush()
	save_file.write('HitId: ' + id);
	
	worker_results = mturk.list_assignments_for_hit(HITId = id, AssignmentStatuses=['Submitted'])
	if worker_results['NumResults'] > 0:
		save_file.write('\n')
		for assignment in worker_results['Assignments']:
			save_file.write('AssignmentId: ' + assignment['AssignmentId'] + '\n')
			save_file.write('WorkerId: ' + assignment['WorkerId'] + '\n')
			save_file.write('FrameNumber: ' + frame_number + '\n')
			xml_doc = xmltodict.parse(assignment['Answer'])
			if type(xml_doc['QuestionFormAnswers']['Answer']) is list:
				for answer_field in xml_doc['QuestionFormAnswers']['Answer']: save_file.write(answer_field['QuestionIdentifier'] + ': ' + answer_field['FreeText'] + '\n')
			else:
				save_file.write(xml_doc['QuestionFormAnswers']['Answer']['QuestionIdentifier'] + ': ' + xml_doc['QuestionFormAnswers']['Answer']['FreeText'] + '\n')

		save_file.write('\n');

		return 1

	else:
		save_file.write(': No answers ready yet\n');
		
		return 0


# main
if __name__ == '__main__':
	mturk = lib.start_session(use_sandbox=0)
	lib.display_balance(mturk);
	
	frame_numbers = lib.get_frame_numbers(vid_id)
	# print(frame_numbers)
	hits = lib.fetch_txt_entries('hits.txt')
	n_completed = 0;
	results_file = open(__file__[:__file__.rfind('/') + 1] + 'results.txt', 'w')
	for it, hit in enumerate(hits): n_completed += get_hit_result(hit, it + 1, len(hits), frame_numbers[it], results_file)
	results_file.close()

	sys.stdout.write('\n' + str(n_completed) +  '/' + str(len(hits)) + ' completed\n')

