import lib
import sys

# constants
do_reject = 1
vid_id = 'GP030088'
rejection_message = ('After careful consideration we had to decide to reject your HIT.\n'
					 'We did not make this decision hastily - please know, that a rejected HIT reflects badly on both the worker and the requester.\n'
					 'We made sure that no submitted HIT has been rejected where our instructions might have led to a wrong undestanding of the task.\n'
					 'With this in mind, we can only ask you to read the instructions more carefully and study the provided examples to fully understand what is required to successfully complete the HIT.\n'
					 'If we have made a mistake with our decision and you would like us to review it, please do not hesitate to send us a mail via Amazon Mechanical Turk.')


# classes
class evaluation_item:
	frame_number = ''
	assignment_id = ''
	is_rejected = 0
	
	def __init__(self, frame_number, assignment_id):
		self.frame_number = frame_number
		self.assignment_id = assignment_id
		pass

	def disp(self):
		sys.stdout.write(self.frame_number + ' ' + self.assignment_id + ' ' + str(self.is_rejected) + '\n')
		pass


# functions
def get_assignments():
	path = __file__[:__file__.rfind('/') + 1] + vid_id + '/'  + 'results.txt'
	rejection_numbers = []
	
	current_assignement_id = ''
	current_frame_number = ''
	eval_table = []
	with open(path, 'r') as file:
		for line in file:
			if not line.find('AssignmentId'):
				current_assignement_id = line[14:-1]
			if not line.find('FrameNumber'):
				current_frame_number = line[13:-1]
				eval_table.append(evaluation_item(current_frame_number, current_assignement_id))
				pass


	return eval_table

def get_rejection_numbers():
	path = __file__[:__file__.rfind('/') + 1] + vid_id + '/'  + 'rejected.txt'
	rejection_numbers = []
	
	with open(path, 'r') as file:
		for line in file:
			if line.find('NP') > 0: rejection_numbers.append(line[:5])
			pass
	
	return rejection_numbers

def create_evaluation_table():
	evaluation_table = get_assignments();
	rejection_numbers = get_rejection_numbers();

	rejection_count = 0
	for item in evaluation_table:
		if item.frame_number in rejection_numbers:
			item.is_rejected = 1
			rejection_count += 1
			pass

	if not do_reject: print(rejection_count, len(rejection_numbers))

	return evaluation_table

def reject(mturk, hit):
	mturk.reject_assignment(AssignmentId=hit.assignment_id,
							RequesterFeedback=rejection_message
							)

	return

def accept(mturk, hit):
	mturk.approve_assignment(AssignmentId=hit.assignment_id)

	return


# main
if __name__ == '__main__':
	mturk = lib.start_session(use_sandbox=0)
	lib.display_balance(mturk)
	evaluation_table = create_evaluation_table()
	
	if not do_reject:
		print(rejection_message)
		sys.exit()

	for	it, item in enumerate(evaluation_table):
		sys.stdout.write('\r' + str(it + 1) + '/' + str(len(evaluation_table)) + ' evaluations completed')
		sys.stdout.flush()
		if item.is_rejected:
			reject(mturk, item)
		else:
			accept(mturk, item)

	sys.stdout.write('\n')

